SECURITY_PASSWORD_SALT = 'fake-salt-123'
SECRET_KEY = 'fake-secret-key-456'
JWT_SECRET_KEY = 'fake-jwt-secret'
JWT_ACCESS_TOKEN_EXPIRES = 3600
CORS_ORIGINS = ['http://localhost:3000']
