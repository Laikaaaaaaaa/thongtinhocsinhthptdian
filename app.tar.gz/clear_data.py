import sqlite3
import os
def clear_student_data():
    """Xóa tất cả dữ liệu học sinh từ database"""
    try:
        db_path = 'students.db'
        if not os.path.exists(db_path):
            print("❌ Database không tồn tại!")
            return
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM students')
        count_before = cursor.fetchone()[0]
        print(f"Hiện có {count_before} học sinh trong database")
        if count_before == 0:
            print("✅ Database đã trống rồi!")
            conn.close()
            return
        print("⚠️  CẢNH BÁO: Sẽ xóa TẤT CẢ dữ liệu học sinh!")
        confirm = input("Bạn có chắc chắn muốn xóa? (y/N): ").lower().strip()
        
        if confirm != 'y':
            print("❌ Hủy bỏ thao tác xóa")
            conn.close()
            return
        cursor.execute('DELETE FROM students')
        cursor.execute('DELETE FROM sqlite_sequence WHERE name="students"')
        conn.commit()
        cursor.execute('SELECT COUNT(*) FROM students')
        count_after = cursor.fetchone()[0]
        print(f"✅ Đã xóa {count_before} học sinh")
        print(f"Hiện còn {count_after} học sinh trong database")
        if count_after == 0:
            print("🎉 Database đã được làm sạch hoàn toàn!")
        conn.close()
    except Exception as e:
        print(f"❌ Lỗi khi xóa dữ liệu: {e}")
if __name__ == "__main__":
    print("CÔNG CỤ XÓA DỮ LIỆU HỌC SINH")
    print("=" * 40)
    clear_student_data()
