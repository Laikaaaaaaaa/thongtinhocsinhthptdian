EMAIL_TEMPLATES_PATH = './templates/email/'
WELCOME_TEMPLATE = 'welcome.html'
RESET_PASSWORD_TEMPLATE = 'reset_password.html'
OTP_TEMPLATE = 'otp.html'
DEFAULT_SENDER = 'noreply@example.com'
SMTP_TIMEOUT = 30
