"""
Script tạo dữ liệu mẫu cho hệ thống THPT Dĩ An
"""

import sqlite3
import random
from datetime import datetime, timedelta

def generate_sample_data(count=150):
    """Tạo dữ liệu mẫu cho testing"""

    first_names = [
        'Nguyễn', 'Trần', 'Lê', 'Phạm', 'Hoàng', 'Huỳnh', 'Phan', 'Vũ', 'Võ', 'Đặng',
        'Bùi', 'Đỗ', 'Hồ', 'Ngô', 'Dương', 'Lý', 'Đinh', 'Đào', 'Cao', 'Lương', 'Mai'
    ]

    middle_names = ['Văn', 'Thị', 'Minh', 'Hoàng', 'Quang', 'Hữu', 'Thanh', 'Anh', 'Thành', 'Bảo', 'Vinh', 'Khánh', 'Nhật', 'Mai', 'Ngọc']

    last_names = [
        'An', 'Bình', 'Cường', 'Dũng', 'Đức', 'Giang', 'Hà', 'Hải', 'Khang', 'Linh',
        'Long', 'Mai', 'Minh', 'Nam', 'Phong', 'Quân', 'Sơn', 'Thảo', 'Tú', 'Vy',
        'Yến', 'Hương', 'Loan', 'Nga', 'Oanh', 'Phương', 'Quyên', 'Thu', 'Trang', 'Xuân'
    ]

    classes = ['10A1', '10A2', '10A3', '10A4', '10A5', '10A6', '10A7', '10A8', '10B1', '10B2', '10B3', '10B4']

    conducts = ['Tốt', 'Khá', 'Trung bình']
    performances = ['Giỏi', 'Khá', 'Trung bình']
    genders = ['Nam', 'Nữ']

    provinces = ['Đồng Nai', 'TP.HCM', 'Bình Dương', 'Long An', 'Tây Ninh']

    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()

    try:
        print(f"🔄 Tạo {count} bản ghi mẫu...")

        for i in range(count):
            first_name = random.choice(first_names)
            middle_name = random.choice(middle_names)
            last_name = random.choice(last_names)
            full_name = f"{first_name} {middle_name} {last_name}"

            email_name = f"{last_name.lower()}.{middle_name.lower()}.{i+100:03d}"
            email = f"{email_name}@student.dian.edu.vn"

            birth_year = random.randint(2005, 2008)
            birth_month = random.randint(1, 12)
            birth_day = random.randint(1, 28)
            birth_date = f"{birth_day:02d}/{birth_month:02d}/{birth_year}"

            gender = random.choice(genders)
            phone = f"0{random.randint(700000000, 999999999)}"
            class_name = random.choice(classes)
            gpa = round(random.uniform(6.5, 9.5), 1)
            conduct = random.choice(conducts)
            performance = random.choice(performances)
            province = random.choice(provinces)

            street_num = random.randint(1, 500)
            current_address = f"{street_num} Đường {random.randint(1, 50)}"

            days_ago = random.randint(0, 30)
            created_at = datetime.now() - timedelta(days=days_ago, hours=random.randint(0, 23), minutes=random.randint(0, 59))

            cursor.execute('''
                INSERT INTO students (
                    email, full_name, birth_date, gender, phone, current_address_detail,
                    class, current_province, created_at,
                    birthplace_province, birthplace_ward,
                    height, weight, smartphone, computer, nationality, ethnicity
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                email, full_name, birth_date, gender, phone, current_address,
                class_name, province, created_at.isoformat(),
                province, f"Phường {random.randint(1, 20)}",
                random.randint(150, 180), random.randint(45, 75),
                random.choice(['Có', 'Không']), random.choice(['Có', 'Không']),
                'Việt Nam', 'Kinh'
            ))

            if (i + 1) % 50 == 0:
                print(f"✅ Đã tạo {i + 1}/{count} bản ghi...")

        conn.commit()
        print(f"Đã tạo thành công {count} bản ghi mẫu!")

        cursor.execute('SELECT COUNT(*) FROM students')
        total = cursor.fetchone()[0]
        print(f"Tổng số bản ghi trong database: {total}")

    except Exception as e:
        print(f"Lỗi tạo dữ liệu mẫu: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == '__main__':
    print("Script tạo dữ liệu mẫu THPT Dĩ An")
    print("=" * 50)

    try:
        count = int(input("Nhập số lượng bản ghi muốn tạo (mặc định 150): ") or 150)
        if count < 1 or count > 1000:
            print("⚠️  Số lượng phải từ 1-1000, sử dụng mặc định 150")
            count = 150
    except ValueError:
        print("⚠️  Giá trị không hợp lệ, sử dụng mặc định 150")
        count = 150

    confirm = input(f"Bạn có chắc muốn tạo {count} bản ghi mẫu? (y/N): ")
    if confirm.lower() in ['y', 'yes']:
        generate_sample_data(count)
    else:
        print("🔴 Đã hủy tạo dữ liệu mẫu")
